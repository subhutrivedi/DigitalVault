import { Component, OnInit } from '@angular/core';
import { HelloWordService } from '../hello-word.service';
import { HttpClient, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-upload-hr',
  templateUrl: './upload-hr.component.html',
  styleUrls: ['./upload-hr.component.css']
})
export class UploadHrComponent implements OnInit {

  message1: string;

  constructor(private helloWorldService: HelloWordService, private httpClient: HttpClient) { }
  selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  imageName: any;

  ngOnInit() {
  }

  //Gets called when the user selects an image
  public onFileChanged(event) {
    this.selectedFile = event.target.files[0];
   }
 
   //Gets called when the user clicks on submit to upload the image
   onUpload() {
     console.log(this.selectedFile);
     //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
     const uploadImageData = new FormData();
     
     uploadImageData.append('file', this.selectedFile, this.selectedFile.name);
     
    // uploadImageData.append('file', this.selectedFile, this.selectedFile.name);
     console.log(uploadImageData.get('file'));
    
 
     //Make a call to the Spring Boot Application to save the image
     this.httpClient.post('http://localhost:8080/api/v1/uploadFile', uploadImageData)
       .subscribe((response) => {
         console.log(response);
       }
     );
     
     alert('File uploaded successfully!!!');
   }
 
       //Gets called when the user clicks on retieve image button to get the image from back end
     getImage() {
     //Make a call to Sprinf Boot to get the Image Bytes.
     this.httpClient.get('http://localhost:8080/image/get/' + this.imageName)
     .subscribe(
         res => {
           this.retrieveResonse = res;
           this.base64Data = this.retrieveResonse.picByte;
           this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
         }
       );
     }

}
