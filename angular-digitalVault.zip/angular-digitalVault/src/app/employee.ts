export class Employee {
    empId: string;
    fname: string;
    lname: string;
    email_id: string;
    mobile_no: string;
    address: string;
    active: boolean;
}