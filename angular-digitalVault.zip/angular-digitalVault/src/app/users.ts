export class Users {
    public username: string;
    public password:string;
    
    
    constructor(username: string,password:string) {
    this.username = name;
    this.password = password;
    }
    }