import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-hr-menu',
  templateUrl: './hr-menu.component.html',
  styleUrls: ['./hr-menu.component.css']
})
export class HrMenuComponent implements OnInit {

  constructor( private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
  }

  onAdd(){
    this.router.navigate(['/add']);
  }

  onEmpList(){
    this.router.navigate(['/employees']);
  }

  onLogout(){
    this.router.navigate(['/login1']);
  }
}
